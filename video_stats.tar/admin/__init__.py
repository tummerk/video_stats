"""Admin panel for Instagram Reels Tracker."""
