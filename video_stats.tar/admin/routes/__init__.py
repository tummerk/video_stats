"""Admin routes package."""
