"""
Mock Test for unified_worker

This script tests the worker logic with mocked Instagram API responses.
Useful for testing worker functionality when Instagram API is blocked or unavailable.
"""
import asyncio
import sys
from datetime import datetime, timezone, timedelta
from unittest.mock import AsyncMock, MagicMock, patch

class MockVideoMetrics:
    """Mock video metrics."""
    def __init__(self, view_count=1000, like_count=50, comment_count=10, followers_count=5000):
        self.view_count = view_count
        self.like_count = like_count
        self.comment_count = comment_count
        self.followers_count = followers_count

class MockVideo:
    """Mock video object."""
    def __init__(self, shortcode="test_shortcode", video_id="12345", account_id=1, days_ago=1):
        self.shortcode = shortcode
        self.video_id = video_id  # This is media_pk
        self.account_id = account_id
        self.published_at = datetime.now(timezone.utc) - timedelta(days=days_ago)
        self.id = 1

async def test_mock_metrics_collection():
    """Test metrics collection with mocked Instagram API."""
    print("=" * 60)
    print("MOCK METRICS COLLECTION TEST")
    print("=" * 60)

    try:
        from src.database.session import get_session
        from src.repositories.metrics_repository import MetricsRepository
        from src.repositories.video_repository import VideoRepository
        from unified_worker import UnifiedWorker

        async with get_session() as session:
            # Get a real video from database (if any)
            video_repo = VideoRepository(session)
            videos = await video_repo.get_all(limit=1)

            if not videos:
                print("\n⚠️  No videos in database. Using mock video.")
                mock_video = MockVideo()
                video_to_test = mock_video
                video_id = str(mock_video.video_id)
            else:
                video_to_test = videos[0]
                video_id = video_to_test.video_id
                print(f"\n✅ Using existing video: {video_to_test.shortcode}")

            # Create worker
            worker = UnifiedWorker()

            # Mock InstagramService methods
            mock_metrics = MockVideoMetrics(
                view_count=5432,
                like_count=123,
                comment_count=45,
                followers_count=9876
            )

            worker.instagram_service.get_video_metrics = AsyncMock(return_value=mock_metrics)

            print(f"\n📊 Mock metrics for video {video_id}:")
            print(f"   Views: {mock_metrics.view_count}")
            print(f"   Likes: {mock_metrics.like_count}")
            print(f"   Comments: {mock_metrics.comment_count}")
            print(f"   Followers: {mock_metrics.followers_count}")

            # Test fetch_metrics_public method
            metrics_data = await worker.fetch_metrics_public(video_id)

            print(f"\n✅ Successfully fetched mock metrics:")
            print(f"   view_count: {metrics_data['view_count']}")
            print(f"   like_count: {metrics_data['like_count']}")
            print(f"   comment_count: {metrics_data['comment_count']}")
            print(f"   followers_count: {metrics_data['followers_count']}")

            # If we have a real video, try saving metrics
            if videos:
                metrics_repo = MetricsRepository(session)
                await metrics_repo.create_metrics_snapshot(
                    video_id=video_to_test.id,
                    view_count=metrics_data['view_count'],
                    like_count=metrics_data['like_count'],
                    comment_count=metrics_data['comment_count'],
                    followers_count=metrics_data['followers_count']
                )
                await session.commit()
                print(f"\n💾 Saved mock metrics to database for {video_to_test.shortcode}")

            print("\n" + "=" * 60)
            print("✅ MOCK METRICS COLLECTION TEST PASSED")
            print("=" * 60)

            return 0

    except Exception as e:
        print(f"\n❌ Mock test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

async def test_mock_video_fetching():
    """Test video fetching with mocked Instagram API."""
    print("\n" + "=" * 60)
    print("MOCK VIDEO FETCHING TEST")
    print("=" * 60)

    try:
        from src.database.session import get_session
        from src.repositories.account_repository import AccountRepository
        from unified_worker import UnifiedWorker

        async with get_session() as session:
            account_repo = AccountRepository(session)
            accounts = await account_repo.get_all()

            if not accounts:
                print("\n⚠️  No accounts in database. Skipping video fetch test.")
                print("   Add accounts to test video fetching.")
                return 0

            print(f"\n✅ Found {len(accounts)} account(s)")

            worker = UnifiedWorker()

            # Mock InstagramService.get_user_recent_videos
            async def mock_get_videos(user_pk, username, limit):
                print(f"\n   Mock fetching {limit} videos for {username} (user_pk: {user_pk})")
                # Simulate successful fetch without actually calling Instagram
                return None

            worker.instagram_service.get_user_recent_videos = AsyncMock(side_effect=mock_get_videos)

            # Test fetch_new_videos
            print("\n🎬 Testing mock video fetching...")
            await worker.fetch_new_videos()

            print("\n✅ Mock video fetching completed without errors")
            print("   (No videos were actually saved to database)")

            print("\n" + "=" * 60)
            print("✅ MOCK VIDEO FETCHING TEST PASSED")
            print("=" * 60)

            return 0

    except Exception as e:
        print(f"\n❌ Mock test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

async def test_scheduler_logic():
    """Test the scheduler logic with different video ages."""
    print("\n" + "=" * 60)
    print("SCHEDULER LOGIC TEST")
    print("=" * 60)

    try:
        from unified_worker import MetricsScheduler
        from datetime import timedelta

        scheduler = MetricsScheduler()

        # Test different video ages
        test_cases = [
            (timedelta(minutes=30), "1h", "Fresh video (< 1 hour)"),
            (timedelta(hours=3), "2h", "Recent video (1-7 hours)"),
            (timedelta(hours=12), "12h", "Day-old video (7-31 hours)"),
            (timedelta(days=3), "1d", "Old video (2-3 days)"),
            (timedelta(days=10), "1d", "Very old video (> 3 days)"),
        ]

        print("\n📅 Testing schedule intervals for different video ages:\n")

        for age, expected_interval, description in test_cases:
            # Create mock video
            mock_video = MockVideo(days_ago=age.total_seconds() / 86400)

            # Calculate expected schedule time
            now = datetime.now(timezone.utc)
            published_at = mock_video.published_at
            video_age = now - published_at

            print(f"   {description}:")
            print(f"   Age: {video_age}")

            # Determine interval based on scheduler logic
            elapsed = timedelta(0)
            target_interval = None

            for i, phase_duration in enumerate(scheduler.PHASE_DURATIONS):
                if video_age <= elapsed + phase_duration:
                    target_interval = scheduler.SCHEDULE_INTERVALS[i]
                    break
                elapsed += phase_duration
            else:
                target_interval = scheduler.SCHEDULE_INTERVALS[-1]

            print(f"   Interval: {target_interval}")
            print(f"   Expected: {expected_interval}")
            print()

        print("=" * 60)
        print("✅ SCHEDULER LOGIC TEST PASSED")
        print("=" * 60)

        return 0

    except Exception as e:
        print(f"\n❌ Scheduler test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

async def main():
    """Run all mock tests."""
    print("\n🧪 Testing unified_worker with mocked Instagram API\n")

    results = []

    # Test 1: Scheduler logic
    result1 = await test_scheduler_logic()
    results.append(("Scheduler Logic", result1))

    # Test 2: Mock metrics collection
    result2 = await test_mock_metrics_collection()
    results.append(("Mock Metrics Collection", result2))

    # Test 3: Mock video fetching
    result3 = await test_mock_video_fetching()
    results.append(("Mock Video Fetching", result3))

    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)

    for name, result in results:
        status = "✅ PASS" if result == 0 else "❌ FAIL"
        print(f"{status}: {name}")

    passed = sum(1 for _, r in results if r == 0)
    total = len(results)

    print(f"\nPassed: {passed}/{total}")

    if passed == total:
        print("\n🎉 ALL MOCK TESTS PASSED!")
        print("\nYour worker logic is working correctly!")
        print("\nNext steps:")
        print("1. Configure Instagram authentication in .env")
        print("2. Run: python unified_worker.py")
        return 0
    else:
        print("\n❌ SOME TESTS FAILED")
        print("\nPlease fix the issues above.")
        return 1

if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
