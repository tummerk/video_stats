"""
Простой скрипт для тестирования скачивания Instagram Reels.

Использование:
    python test_download.py

Скрипт попросит ввести ссылку на Instagram Reel и:
1. Скачает аудио (MP3)
2. Транскрибирует аудио через Whisper
3. Сохранит всё в папку audio/

Пример ссылки:
    https://www.instagram.com/reels/DAAAAAA/
    https://www.instagram.com/reel/DAAAAAA/
"""
import asyncio
import logging
import re
from pathlib import Path

import yt_dlp
import whisper

from src.config import settings

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def extract_shortcode(url: str) -> str:
    """Извлечь shortcode из ссылки Instagram."""
    # Паттерны для разных форматов ссылок
    patterns = [
        r'/reel/([A-Za-z0-9_-]+)/',
        r'/reels/([A-Za-z0-9_-]+)/',
        r'/p/([A-Za-z0-9_-]+)/',
    ]

    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)

    raise ValueError(f"Не удалось извлечь shortcode из URL: {url}")


def download_reel(url: str, shortcode: str) -> dict:
    """Скачать аудио с Instagram Reel через yt-dlp."""
    audio_dir = Path(settings.audio_dir)
    audio_dir.mkdir(parents=True, exist_ok=True)

    audio_filename = audio_dir / f"{shortcode}.mp3"

    logger.info(f"📥 Скачивание аудио для {shortcode}...")

    # Шаг 1: Метаданные
    ydl_opts_meta = {
        'quiet': True,
        'noprogress': True,
        'skip_download': True,
    }

    with yt_dlp.YoutubeDL(ydl_opts_meta) as ydl:
        info = ydl.extract_info(url, download=False)

    # Шаг 2: Скачивание аудио
    ydl_opts_audio = {
        'format': 'bestaudio/best',
        'outtmpl': str(audio_filename.with_suffix('')),
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        'quiet': True,
        'noprogress': False,  # Показываем прогресс
    }

    with yt_dlp.YoutubeDL(ydl_opts_audio) as ydl:
        ydl.download([url])

    if not audio_filename.exists():
        raise FileNotFoundError(f"Аудиофайл не был создан: {audio_filename}")

    return {
        'id': info.get('id'),
        'webpage_url': info.get('webpage_url'),
        'description': info.get('description'),
        'duration': info.get('duration'),
        'audio_file_path': str(audio_filename),
    }


def transcribe_audio(audio_path: str) -> str:
    """Транскрибировать аудио через Whisper."""
    logger.info("🎙️  Транскрибация аудио через Whisper...")

    model = whisper.load_model("base")
    result = model.transcribe(audio_path, fp16=False)

    transcription = result['text'].strip()
    return transcription


def main():
    """Главная функция."""
    print("=" * 70)
    print("📹 INSTAGRAM REEL DOWNLOAD TESTER")
    print("=" * 70)
    print()

    while True:
        # Ввод ссылки
        url = input("Введите ссылку на Instagram Reel (или 'q' для выхода): ").strip()

        if url.lower() == 'q':
            print("👋 Выход...")
            break

        if not url:
            print("⚠️  Ссылка не может быть пустой")
            print()
            continue

        # Проверка формата ссылки
        try:
            shortcode = extract_shortcode(url)
        except ValueError as e:
            print(f"❌ {e}")
            print("💡 Пример: https://www.instagram.com/reels/DAAAAAA/")
            print()
            continue

        print(f"\n✅ Shortcode: {shortcode}")
        print(f"📁 Папка для сохранения: {settings.audio_dir}")
        print()

        try:
            # Скачивание
            result = download_reel(url, shortcode)

            print(f"✅ Аудио сохранено: {result['audio_file_path']}")
            print(f"   Размер: {Path(result['audio_file_path']).stat().st_size / 1024 / 1024:.2f} MB")
            print()

            # Транскрибация
            transcription = transcribe_audio(result['audio_file_path'])

            print(f"📝 Транскрипция:")
            print("-" * 70)
            print(transcription)
            print("-" * 70)
            print()

            # Информация о видео
            if result.get('description'):
                print(f"📄 Описание:")
                print(result['description'][:200] + "..." if len(result['description']) > 200 else result['description'])
                print()

            if result.get('duration'):
                print(f"⏱️  Длительность: {result['duration']} секунд")
                print()

            print("=" * 70)
            print()

        except Exception as e:
            logger.exception(f"❌ Ошибка: {e}")
            print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Прервано пользователем")
    except Exception as e:
        logger.exception(f"Критическая ошибка: {e}")
