"""
Database Connection Test

This script tests database connectivity and data without using Instagram API.
Useful when your provider blocks Instagram or for initial setup verification.
"""
import asyncio
import sys
from datetime import datetime, timezone

async def test_database_connection():
    """Test database connection and display basic info."""
    print("=" * 60)
    print("DATABASE CONNECTION TEST")
    print("=" * 60)

    try:
        from src.database.session import get_session
        from src.repositories.account_repository import AccountRepository
        from src.repositories.video_repository import VideoRepository
        from src.repositories.metrics_repository import MetricsRepository
        from src.repositories.metric_schedule_repository import MetricScheduleRepository
        from sqlalchemy import text

        async with get_session() as session:
            # Test 1: Basic connection
            print("\n✅ Database connection successful")

            # Test 2: Check tables
            result = await session.execute(text("""
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = 'public'
                AND table_type = 'BASE TABLE'
                ORDER BY table_name
            """))
            tables = [row[0] for row in result.fetchall()]

            print(f"\n📊 Found {len(tables)} tables:")
            for table in tables:
                print(f"   - {table}")

            # Test 3: Check accounts
            account_repo = AccountRepository(session)
            accounts = await account_repo.get_all()

            print(f"\n👥 Found {len(accounts)} account(s):")
            if not accounts:
                print("   ⚠️  No accounts in database!")
                print("   You need to add accounts to track Instagram profiles.")
            else:
                for account in accounts:
                    print(f"   - {account.username} (ID: {account.id}, user_pk: {account.id})")

            # Test 4: Check videos
            video_repo = VideoRepository(session)
            # Get recent videos
            result = await session.execute(text("SELECT COUNT(*) FROM videos"))
            video_count = result.scalar()

            print(f"\n🎬 Found {video_count} video(s) in database")

            if video_count > 0:
                result = await session.execute(text("""
                    SELECT shortcode, account_id, published_at
                    FROM videos
                    ORDER BY published_at DESC
                    LIMIT 5
                """))
                recent_videos = result.fetchall()

                print("\n   Most recent videos:")
                for shortcode, account_id, published_at in recent_videos:
                    age_days = (datetime.now(timezone.utc) - published_at.replace(tzinfo=timezone.utc)).days
                    print(f"   - {shortcode} (account: {account_id}, age: {age_days}d)")

            # Test 5: Check metrics
            result = await session.execute(text("SELECT COUNT(*) FROM metrics"))
            metrics_count = result.scalar()

            print(f"\n📈 Found {metrics_count} metric snapshot(s)")

            if metrics_count > 0:
                result = await session.execute(text("""
                    SELECT m.recorded_at, v.shortcode, m.view_count
                    FROM metrics m
                    JOIN videos v ON m.video_id = v.id
                    ORDER BY m.recorded_at DESC
                    LIMIT 5
                """))
                recent_metrics = result.fetchall()

                print("\n   Most recent metrics:")
                for recorded_at, shortcode, view_count in recent_metrics:
                    print(f"   - {shortcode}: {view_count} views at {recorded_at}")

            # Test 6: Check schedules
            schedule_repo = MetricScheduleRepository(session)
            pending = await schedule_repo.get_pending_schedules()

            print(f"\n⏰ Found {len(pending)} pending schedule(s)")

            if pending:
                print("\n   Upcoming schedules:")
                for schedule in pending[:5]:
                    print(f"   - {schedule.video.shortcode} at {schedule.scheduled_at}")

            print("\n" + "=" * 60)
            print("✅ DATABASE TEST PASSED")
            print("=" * 60)

            if not accounts:
                print("\n⚠️  WARNING: No accounts found in database!")
                print("   Add accounts to start tracking Instagram profiles.")
                return 1

            return 0

    except Exception as e:
        print(f"\n❌ Database test failed: {e}")
        print("\nTroubleshooting:")
        print("1. Check that PostgreSQL is running")
        print("2. Verify DATABASE_URL in .env file")
        print("3. Ensure database exists")
        print("4. Run migrations: alembic upgrade head")
        return 1

async def test_worker_logic():
    """Test worker logic without Instagram API."""
    print("\n" + "=" * 60)
    print("WORKER LOGIC TEST (without Instagram API)")
    print("=" * 60)

    try:
        from src.database.session import get_session
        from src.repositories.metric_schedule_repository import MetricScheduleRepository
        from src.repositories.video_repository import VideoRepository
        from unified_worker import MetricsScheduler

        async with get_session() as session:
            video_repo = VideoRepository(session)
            schedule_repo = MetricScheduleRepository(session)

            # Get videos that need schedules
            videos = await video_repo.get_videos_for_schedule_update(limit=10)

            print(f"\n📋 Found {len(videos)} video(s) needing schedule updates")

            scheduler = MetricsScheduler()

            for video in videos:
                print(f"\n   Processing: {video.shortcode}")
                await scheduler.create_schedule_for_video(video, schedule_repo)

            await session.commit()

            print("\n✅ Schedule creation test passed")

            # Check pending schedules
            pending = await schedule_repo.get_pending_schedules()
            print(f"📅 Total pending schedules: {len(pending)}")

            print("\n" + "=" * 60)
            print("✅ WORKER LOGIC TEST PASSED")
            print("=" * 60)

            return 0

    except Exception as e:
        print(f"\n❌ Worker logic test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

async def main():
    """Run all tests."""
    print("\n🧪 Testing unified_worker environment (without Instagram API)\n")

    # Test 1: Database connection
    result1 = await test_database_connection()

    # Test 2: Worker logic
    result2 = await test_worker_logic()

    if result1 == 0 and result2 == 0:
        print("\n" + "=" * 60)
        print("🎉 ALL TESTS PASSED!")
        print("=" * 60)
        print("\nYour database is ready to run unified_worker.py")
        print("\nNext steps:")
        print("1. Configure Instagram authentication in .env:")
        print("   - INSTAGRAM_SESSIONID (recommended)")
        print("   - or INSTAGRAM_USERNAME/PASSWORD")
        print("\n2. Run the worker:")
        print("   python unified_worker.py")
        print("\nOr test with mock data:")
        print("   python test_worker_mock.py")
        return 0
    else:
        print("\n" + "=" * 60)
        print("❌ SOME TESTS FAILED")
        print("=" * 60)
        print("\nPlease fix the issues above before running the worker.")
        return 1

if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
