"""Simple database test without emoji."""
import asyncio
from src.database.session import get_session
from src.models import WorkerHeartbeat
from sqlalchemy import select


async def test():
    print("Testing database connection...")
    try:
        async with get_session() as session:
            result = await session.execute(select(WorkerHeartbeat))
            heartbeats = result.scalars().all()
            print(f"SUCCESS: Connected to database")
            print(f"Found {len(heartbeats)} heartbeat records")

            if heartbeats:
                for hb in heartbeats:
                    print(f"Worker: {hb.worker_name}, Status: {hb.status}")

            return True
    except Exception as e:
        print(f"ERROR: {e}")
        return False


if __name__ == "__main__":
    result = asyncio.run(test())
    print("\nEverything is ready!")
    print("Run: python unified_worker.py")
    print("Then in another terminal: python run_admin.py")
